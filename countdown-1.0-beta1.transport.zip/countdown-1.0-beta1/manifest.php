<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '53bf7cc3cde60a681cd335727d8c7511',
      'native_key' => 'countdown',
      'filename' => 'modNamespace/f6beaa4075128620849487a361dd60e9.vehicle',
      'namespace' => 'countdown',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'fe28aa496a920e4a61c8004ecd5cf544',
      'native_key' => 1,
      'filename' => 'modCategory/a09f20ea8b29a61d7b69379a9382ba38.vehicle',
      'namespace' => 'countdown',
    ),
  ),
);